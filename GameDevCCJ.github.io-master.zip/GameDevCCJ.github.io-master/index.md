


<a href="games.html" class="button button5">Games</a> <a href="log.html" class="button button5">Log</a> <a href="Chatroom.html" class="button button5">Chatroom</a>



 <h1><a href="https://gamedevccj.github.io/James4/Chatroom.html">CHATROOOM</a></h1>
<h2> BOOKMARKLETS </h2>
<p><a href="javascript:(function()%7Bjavascript%3Avar%20DELAY%20%3D%201%3Bvar%20autoClickerStyleElement%20%3D%20document.createElement(%22style%22)%3BautoClickerStyleElement.innerHTML%3D%22*%7Bcursor%3A%20crosshair%20!important%3B%7D%22%3Bdocument.body.appendChild(autoClickerStyleElement)%3Bfunction%20addClicker(e)%20%7Bif(!e.isTrusted)%20%7Breturn%3B%7Dif(e.target.classList.contains(%22auto-clicker-target%22))%20%7Be.target.classList.remove(%22auto-clicker-target%22)%3B%7D%20else%20%7Be.target.classList.add(%22auto-clicker-target%22)%3B%7Ddocument.body.removeChild(autoClickerStyleElement)%3Bdocument.body.removeEventListener(%22click%22%2C%20addClicker)%3Be.preventDefault()%3BautoClick(e.target)%3B%7Dfunction%20autoClick(element)%20%7Bif(element.classList.contains(%22auto-clicker-target%22))%20%7Belement.click()%3BsetTimeout(function()%7B%20autoClick(element)%3B%20%7D%2C%20DELAY)%3B%7D%7Ddocument.body.addEventListener(%22click%22%2C%20addClicker%2C%200)%3B%7D)()%3B">Auto Clicker</a></p>
<p><a href="javascript:(function()%7Bjavascript%3A(function()%7Bvar%20a%3Ddocument.createElement(%22script%22)%3Ba.src%3D%22https%3A%2F%2Fx-ray-goggles.mouse.org%2Fwebxray.js%22%3Ba.className%3D%22webxray%22%3Ba.setAttribute(%22data-lang%22%2C%22en-US%22)%3Ba.setAttribute(%22data-baseuri%22%2C%22https%3A%2F%2Fx-ray-goggles.mouse.org%22)%3Bdocument.body.appendChild(a)%3B%7D())%3B%7D)()%3B">Inspect element/ xRay</a></p>
<p><a href="javascript:var s=document.createElement('script');s.type='text/javascript';s.src='https://sheeptester.github.io/javascripts/eval.js';document.body.appendChild(s);void(0);">eval.js</a></p>
 <p><a href="https://gamedevccj.github.io/James4/Chatroom.html">CHATROOOM</a></p>
<h3></h3><!-- Start BawkBox Code--><script data-sil-id="6328799dcac98e0013e24d55">var loadWidget = function() { var d = document, w = window, l = window.location,p = l.protocol == "file:" ? "http://" : "//"; if (!w.WS) w.WS = {}; c = w.WS; var m=function(t, o){ var e = d.getElementsByTagName("script"); e=e[e.length-1]; var n = d.createElement(t); if (t=="script") {n.async=true;} for (k in o) n[k] = o[k]; e.parentNode.insertBefore(n, e)}; m("script", { src: p + "bawkbox.com/widget/feedback/6328799dcac98e0013e24d55?page=" +encodeURIComponent(l+''), type: 'text/javascript' }); c.load_net = m; }; if(window.Squarespace){ document.addEventListener('DOMContentLoaded', loadWidget); setTimeOut(function(){ document.addEventListener('DOMContentLoaded', loadWidget); }, 3000) } else { loadWidget() } </script><div class="sil-widget-feedback sil-widget" id="sil-widget-6328799dcac98e0013e24d55"><a href="//bawkbox.com/install/feedback"></a></div><!-- End BawkBox Code-->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5234855808554952"
     crossorigin="anonymous"></script>
</body>
<head>
<body>

<p> yo welcome to my website </p> 
     


<html>
<head>
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 2px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 2px solid #e7e7e7;
}

.button4:hover {background-color: #e7e7e7;}

.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}
</style>
</head>
<body>


</head>
